#!/bin/bash
# i-matik
rm -f $FREETZ_SSL_HOME_PATH/make/pkgs/mod/files/root/usr/lib/mww/cgi/menu-new.sh 2>/dev/null
mv $FREETZ_SSL_HOME_PATH/make/pkgs/mod/files/root/usr/lib/mww/cgi/menu-new.sh.orig $FREETZ_SSL_HOME_PATH/make/pkgs/mod/files/root/usr/lib/mww/cgi/menu-new.sh 2>/dev/null
